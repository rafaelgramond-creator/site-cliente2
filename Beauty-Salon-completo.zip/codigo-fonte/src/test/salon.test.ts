import { describe, it, expect } from "vitest";
import { salonContact, simulateContact } from "@/lib/salon";

describe("Salon demonstration constraints", () => {
  it("uses the prospect's supplied phone", () => { expect(salonContact.phone).toBe("+5511964265382"); });
  it("uses the prospect's supplied address", () => { expect(salonContact.address).toBe("R. Jequirituba, 1515 - Parque America, São Paulo - SP, 04822-000, Brasil"); });
  it("does not invent business hours", () => { expect(salonContact.hours).toBeNull(); });
  it("marks supplied contact facts as unverified", () => { expect(salonContact.verified).toBe(false); });
  it("only simulates a contact without sending", () => { const result = simulateContact("Rafael"); expect(result.simulated).toBe(true); expect(result.sent).toBe(false); });
});