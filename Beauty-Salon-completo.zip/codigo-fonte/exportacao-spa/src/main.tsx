import React from "react";
import { createRoot } from "react-dom/client";
import BeautySalon from "./BeautySalon";
import "./styles.css";
import "./fonts.css";
const root = document.getElementById("root");
if (root) createRoot(root).render(<BeautySalon />);
