export const salonContact = {
  phone: "+5511964265382",
  displayPhone: "(11) 96426-5382",
  address: "R. Jequirituba, 1515 - Parque America, São Paulo - SP, 04822-000, Brasil",
  hours: null,
  verified: false,
};

export const services = [
  { id: "corte", category: "Cabelos", title: "Corte & finalização", description: "Forma, movimento e possibilidades para expressar seu estilo.", number: "01" },
  { id: "cor", category: "Cabelos", title: "Cor & iluminação", description: "Tons e nuances como inspiração para um novo olhar.", number: "02" },
  { id: "unhas", category: "Unhas", title: "Manicure & pedicure", description: "O cuidado nos detalhes, com cores que traduzem você.", number: "03" },
  { id: "beleza", category: "Beleza", title: "Make & sobrancelhas", description: "Uma proposta para valorizar sua expressão natural.", number: "04" },
];

export function simulateContact(name: string) {
  return { simulated: true, sent: false, message: `${name.trim()}, sua solicitação foi simulada. Nenhuma mensagem foi enviada e nenhum agendamento foi realizado.` };
}