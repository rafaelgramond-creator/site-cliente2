import { useState, type FormEvent } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { ArrowUpRight, ArrowDown, ArrowRight, Phone, MapPin, Clock3, Menu, X, Scissors, Sparkles, Flower2, Heart, Leaf, Plus, Info, ImageIcon, Check, MoveUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { salonContact, services, simulateContact } from "@/lib/salon";
import heroImage from "@/assets/beauty-hero.jpg";
import hairImage from "@/assets/hair-editorial.jpg";
import nailsImage from "@/assets/nails-editorial.jpg";

const navigation = [{ label: "Serviços", id: "servicos" }, { label: "O conceito", id: "conceito" }, { label: "Inspirações", id: "inspiracoes" }, { label: "Contato", id: "contato" }];
const gallery = [
  { image: hairImage, title: "Movimento natural", category: "Cabelos", alt: "Retrato ilustrativo de mulher com cabelos castanhos ondulados" },
  { image: nailsImage, title: "Beleza nos detalhes", category: "Unhas", alt: "Fotografia ilustrativa de manicure em tom nude terracota" },
  { image: heroImage, title: "Sua essência em destaque", category: "Beleza", alt: "Retrato beauty ilustrativo com maquiagem natural" },
];
const icons = [Scissors, Sparkles, Flower2, Heart];

function Photo({ src, alt, className, hero = false }: { src: string; alt: string; className?: string; hero?: boolean }) {
  const [failed, setFailed] = useState(false);
  if (failed) return <div className={`image-fallback ${hero ? "hero-fallback" : ""}`} role="img" aria-label={alt}><ImageIcon size={30} /><span>Beleza em sua essência</span><small>Imagem ilustrativa indisponível</small></div>;
  return <img src={src} alt={alt} className={className} width={hero ? 1920 : 832} height={1088} loading={hero ? "eager" : "lazy"} onError={() => setFailed(true)} />;
}

export default function Index() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [filter, setFilter] = useState("Todos");
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [service, setService] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const selected = selectedImage !== null ? gallery[selectedImage] : undefined;
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(salonContact.address)}`;
  function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    setConfirmation(simulateContact(String(formData.get("name") || "")).message);
  }
  return <>
    <header className="salon-header">
      <div className="salon-wrap header-inner">
        <a href="#inicio" aria-label="Beauty Salon, início" className="wordmark">beauty <span>salon.</span></a>
        <nav className="desktop-nav" aria-label="Navegação principal">{navigation.map(item => <a key={item.id} href={`#${item.id}`}>{item.label}</a>)}</nav>
        <div className="header-actions"><span className="demo-badge">Prévia demonstrativa</span><Button asChild variant="salon" size="sm" className="header-contact"><a href="#contato">Vamos conversar <ArrowUpRight /></a></Button><Button variant="ghost" size="icon" className="mobile-menu-toggle" aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</Button></div>
      </div>
      {menuOpen && <nav className="salon-wrap mobile-nav" aria-label="Navegação mobile">{navigation.map(item => <a key={item.id} href={`#${item.id}`} onClick={() => setMenuOpen(false)}>{item.label}</a>)}</nav>}
    </header>
    <main>
      <section className="hero" id="inicio" aria-labelledby="hero-title">
        <Photo src={heroImage} alt="Retrato editorial ilustrativo de beleza natural" className="hero-photo" hero />
        <div className="salon-wrap hero-content"><div className="reveal"><p className="eyebrow">Beauty Salon · beleza & cuidado</p><h1 id="hero-title">Beleza,<br />no seu <em>tempo.</em></h1></div><div className="reveal reveal-delay"><p className="hero-description">Uma pausa para se olhar com carinho.<br />Um novo jeito de valorizar o que é seu.</p><div className="hero-ctas"><Button asChild variant="salon"><a href="#servicos">Explore os serviços <ArrowUpRight /></a></Button><Button asChild variant="editorial"><a href="#contato">Entre em contato <Phone size={14} /></a></Button></div><p className="hero-note"><MapPin size={12} /> Parque America, São Paulo <span>·</span> Localização a confirmar</p></div></div>
        <a href="#servicos" className="hero-bottom">Seu momento começa aqui <ArrowDown size={15} /></a><span className="hero-caption">RETRATO ILUSTRATIVO</span>
      </section>
      <div className="manifesto-strip"><div className="salon-wrap strip-content"><p>Mais do que beleza. <em>Um olhar para você.</em></p><span><Flower2 size={17} /> Cuidado nos detalhes</span><span><Leaf size={17} /> Essência natural</span><span><Heart size={17} /> Tempo para si</span></div></div>
      <section id="servicos" className="section salon-wrap">
        <div className="section-heading"><div><p className="eyebrow">Possibilidades de cuidado</p><h2>Seu estilo.<br /><em>Novas possibilidades.</em></h2></div><p className="section-description">Do movimento dos cabelos ao acabamento das unhas, uma seleção de cuidados para inspirar seu próximo momento de beleza.</p></div>
        <div className="filters" aria-label="Filtrar serviços">{["Todos", "Cabelos", "Unhas", "Beleza"].map(category => <Button key={category} variant="filter" data-active={filter === category} aria-pressed={filter === category} onClick={() => setFilter(category)}>{category}</Button>)}</div>
        <div className="service-grid">{services.filter(item => filter === "Todos" || item.category === filter).map(item => { const Icon = icons[Number(item.number) - 1] ?? Sparkles; return <article className="service-card" key={item.id}><div className="service-top"><Icon size={25} strokeWidth={1.2} /><span>{item.number}</span></div><h3>{item.title}</h3><p>{item.description}</p><a href="#contato" onClick={() => { setService(item.title); setConfirmation(""); }}>Consultar serviço <ArrowUpRight size={14} /></a></article>; })}</div>
        <p className="section-footnote"><Info size={12} /> Serviços sugeridos para apresentação. Disponibilidade, valores e detalhes sujeitos à confirmação.</p>
      </section>
      <section className="section experience" id="conceito"><div className="salon-wrap experience-grid">
        <div className="experience-photo"><Photo src={hairImage} alt="Retrato ilustrativo de cabelo ondulado e beleza natural" /><span className="photo-label">Imagem ilustrativa · não é trabalho do salão</span><div className="organic-stamp"><Flower2 size={27} strokeWidth={1} /><span>seja você.</span></div></div>
        <div className="experience-copy"><p className="eyebrow">A essência do conceito</p><h2>O luxo de<br /><em>se sentir bem.</em></h2><p>Beleza sem pressa, com espaço para a sua individualidade. Este conceito imagina um encontro entre o cuidado, a leveza e a expressão pessoal.</p><div className="concept-list"><div className="concept-row"><Heart size={20} strokeWidth={1.2} /><div><h3>Um olhar acolhedor</h3><p>Você e sua essência no centro da inspiração.</p></div></div><div className="concept-row"><Sparkles size={20} strokeWidth={1.2} /><div><h3>Beleza com personalidade</h3><p>Possibilidades que celebram diferentes estilos.</p></div></div><div className="concept-row"><Leaf size={20} strokeWidth={1.2} /><div><h3>Leveza em cada detalhe</h3><p>Uma proposta visual natural e contemporânea.</p></div></div></div><p className="section-footnote">Proposta conceitual, não uma descrição verificada do salão.</p></div>
      </div></section>
      <section id="inspiracoes" className="section salon-wrap"><div className="section-heading"><div><p className="eyebrow">Um olhar, muitas inspirações</p><h2>Beleza que <em>inspira.</em></h2></div><p className="section-description">Texturas, cores e formas em uma seleção editorial. Imagens ilustrativas, sem vínculo com trabalhos realizados pelo Beauty Salon.</p></div><div className="gallery-grid">{gallery.map((item, index) => <article key={item.title} className="gallery-item"><Button variant="ghost" className="gallery-button" aria-label={`Ampliar ${item.title}`} onClick={() => setSelectedImage(index)}><Photo src={item.image} alt={item.alt} /><span className="zoom-icon"><Plus size={17} /></span></Button><h3>{item.title}</h3><p>{item.category} · Referência ilustrativa</p></article>)}</div></section>
      <section className="pause-band"><div className="salon-wrap"><p className="eyebrow">Um convite ao autocuidado</p><h2>Reserve um tempo.<br /><em>Para você.</em></h2><Button asChild variant="editorial"><a href="#contato">Converse sobre seu próximo cuidado <ArrowUpRight /></a></Button></div></section>
      <section id="contato" className="section salon-wrap"><div className="section-heading"><div><p className="eyebrow">Estamos por perto</p><h2>Vamos <em>conversar?</em></h2></div><p className="section-description">Consulte os serviços e os horários diretamente pelo telefone. Os dados abaixo foram fornecidos para esta prévia e ainda não foram verificados.</p></div><div className="contact-grid"><div>
        <div className="contact-row"><Phone size={21} strokeWidth={1.3} /><div><h3>Contato direto</h3><a href={`tel:${salonContact.phone}`}>{salonContact.displayPhone}</a><small>Telefone informado · a confirmar</small></div></div>
        <div className="contact-row"><MapPin size={21} strokeWidth={1.3} /><div><h3>Onde encontrar</h3><p>R. Jequirituba, 1515 — Parque America<br />São Paulo — SP, 04822-000, Brasil</p><small>Endereço informado · a confirmar</small><a className="map-link" href={mapsUrl} target="_blank" rel="noopener noreferrer">Ver endereço no mapa <MoveUpRight size={13} /></a></div></div>
        <div className="contact-row"><Clock3 size={21} strokeWidth={1.3} /><div><h3>Horários de atendimento</h3><p>A confirmar com o salão</p><small>Consulte por telefone antes de sua visita.</small></div></div>
        <Button asChild variant="salon" size="lg" className="mt-5"><a href={`tel:${salonContact.phone}`}><Phone /> Ligar para o salão <ArrowUpRight /></a></Button>
      </div><form className="contact-form" onSubmit={submitForm}><h3>Seu próximo cuidado</h3><p>Formulário demonstrativo: nenhuma informação será enviada ou armazenada. Não realiza agendamentos.</p><label className="form-label">Seu nome<input className="form-field" name="name" placeholder="Como podemos chamar você?" required maxLength={100} onChange={() => setConfirmation("")} /></label><label className="form-label">O que você tem em mente?<select className="form-field" name="service" value={service} onChange={event => { setService(event.target.value); setConfirmation(""); }} required><option value="" disabled>Selecione um serviço sugerido</option>{services.map(item => <option key={item.id}>{item.title}</option>)}<option>Quero conhecer as possibilidades</option></select></label><label className="form-label">Sua mensagem <span className="sr-only">opcional</span><textarea className="form-field" name="message" placeholder="Conte um pouco sobre o que você gostaria (opcional)" maxLength={1000} /></label><Button variant="salon" type="submit" className="form-submit">Simular solicitação <ArrowRight /></Button>{confirmation && <div className="simulation-result" role="status"><Check size={18} className="mb-2" /><strong>Simulação concluída</strong><p>{confirmation}</p></div>}</form></div></section>
    </main>
    <footer className="salon-footer"><div className="salon-wrap"><div className="footer-top"><div><a href="#inicio" className="wordmark">beauty <span>salon.</span></a><p>Um conceito de beleza. Um tempo para você.<br />Marca tipográfica conceitual, não um logotipo oficial.</p></div><div className="footer-credit">Prévia demonstrativa<br />Apresentação comercial por <strong>Rafael</strong><br />Fotografias geradas por IA, exclusivamente ilustrativas.<br />Não representam clientes, equipe ou trabalhos reais.</div></div><div className="footer-bottom"><p>Conceito visual independente • Informações e serviços sujeitos à confirmação</p><a href="#inicio">Voltar ao início ↑</a></div></div></footer>
    <Dialog.Root open={selected !== undefined} onOpenChange={open => { if (!open) setSelectedImage(null); }}><Dialog.Portal><Dialog.Overlay className="modal-overlay" /><Dialog.Content className="modal-content"><div className="modal-head"><Dialog.Title>{selected?.title ?? "Inspiração editorial"}</Dialog.Title><Dialog.Close asChild><Button variant="ghost" size="icon" aria-label="Fechar imagem"><X /></Button></Dialog.Close></div>{selected && <Photo src={selected.image} alt={selected.alt} />}<Dialog.Description className="modal-description">Referência editorial ilustrativa, gerada por IA. Esta imagem não representa um trabalho realizado pelo Beauty Salon.</Dialog.Description><div className="flex justify-between mt-4"><Button variant="editorial" onClick={() => setSelectedImage(previous => ((previous ?? 0) + gallery.length - 1) % gallery.length)}>Anterior</Button><Button variant="editorial" onClick={() => setSelectedImage(previous => ((previous ?? 0) + 1) % gallery.length)}>Próxima <ArrowRight /></Button></div></Dialog.Content></Dialog.Portal></Dialog.Root>
  </>;
}
